package com.hakamo.nursingassistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Section(
    val title: String,
    val subtitle: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)

private val sections = listOf(
    Section("دليل الأدوية", "معلومات الأدوية", Icons.Default.MedicalServices),
    Section("الحاسبات الطبية", "حسابات التمريض", Icons.Default.Calculate),
    Section("أساسيات التمريض", "المهارات الأساسية", Icons.Default.LocalHospital),
    Section("معلومات تمريضية", "شروحات مبسطة", Icons.Default.MenuBook),
    Section("المصطلحات الطبية", "عربي - English", Icons.Default.Translate),
    Section("الإجراءات التمريضية", "خطوات عملية", Icons.Default.Favorite),
    Section("الطوارئ والإسعافات", "تصرفات سريعة", Icons.Default.Emergency),
    Section("المذاكرة والمراجعة", "ملخصات وأسئلة", Icons.Default.School)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HakamoApp() }
    }
}

@Composable
private fun HakamoApp() {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF35D0BA),
            secondary = Color(0xFF65B9FF),
            background = Color(0xFF07131F),
            surface = Color(0xFF0D1D2B)
        )
    ) {
        HomeScreen()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HomeScreen() {
    var search by remember { mutableStateOf("") }
    val filtered = sections.filter {
        search.isBlank() ||
        it.title.contains(search, ignoreCase = true) ||
        it.subtitle.contains(search, ignoreCase = true)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Spacer(Modifier.height(20.dp))
        Text(
            "Hakamo",
            color = MaterialTheme.colorScheme.primary,
            fontSize = 34.sp,
            fontWeight = FontWeight.ExtraBold
        )
        Text(
            "مساعدك في كل ما يخص التمريض",
            color = Color.White.copy(alpha = .85f),
            fontSize = 16.sp
        )
        Spacer(Modifier.height(18.dp))
        OutlinedTextField(
            value = search,
            onValueChange = { search = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            placeholder = { Text("ابحث داخل التطبيق...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "بحث") },
            shape = RoundedCornerShape(18.dp)
        )
        Spacer(Modifier.height(18.dp))
        Text(
            "الأقسام الرئيسية",
            color = Color.White,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(10.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 20.dp)
        ) {
            items(filtered) { section ->
                Card(
                    modifier = Modifier.fillMaxWidth().height(145.dp),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(14.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Icon(
                            section.icon,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(34.dp)
                        )
                        Column {
                            Text(
                                section.title,
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                section.subtitle,
                                color = Color.White.copy(alpha = .65f),
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
