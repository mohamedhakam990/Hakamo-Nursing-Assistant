package com.hakamo.nursingassistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Drug(val name: String, val generic: String, val use: String, val warning: String)
data class Term(val ar: String, val en: String, val desc: String)

val drugs = listOf(
    Drug("باراسيتامول", "Paracetamol", "مسكن وخافض للحرارة", "الانتباه للجرعة اليومية وتجنب تكرار المادة الفعالة."),
    Drug("أموكسيسيلين", "Amoxicillin", "مضاد حيوي للبكتيريا", "التأكد من الحساسية والالتزام بوصفة الطبيب."),
    Drug("سيفترياكسون", "Ceftriaxone", "مضاد حيوي من السيفالوسبورينات", "يُعطى حسب الوصفة والبروتوكول وتُراجع الحساسية."),
    Drug("فوروسيميد", "Furosemide", "مدر للبول", "متابعة الضغط، السوائل والإلكتروليتات حسب الحالة."),
    Drug("أوندانسيترون", "Ondansetron", "مضاد للغثيان والقيء", "يُراجع التاريخ الدوائي والحالة قبل الإعطاء.")
)

val terms = listOf(
    Term("ضغط الدم", "Blood Pressure", "قوة الدم على جدران الأوعية الدموية."),
    Term("معدل النبض", "Heart Rate", "عدد ضربات القلب في الدقيقة."),
    Term("معدل التنفس", "Respiratory Rate", "عدد مرات التنفس في الدقيقة."),
    Term("تشبع الأكسجين", "SpO₂", "نسبة تشبع الهيموجلوبين بالأكسجين."),
    Term("الوريد", "Vein", "وعاء دموي يعيد الدم باتجاه القلب.")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HakamoApp() }
    }
}

@Composable
fun HakamoApp() {
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFF35D0BA),
        secondary = Color(0xFF65B9FF),
        background = Color(0xFF07131F),
        surface = Color(0xFF0D1D2B)
    )) {
        var screen by remember { mutableStateOf("home") }
        var search by remember { mutableStateOf("") }

        when (screen) {
            "home" -> HomeScreen(
                search = search,
                onSearch = { search = it },
                onSection = { screen = it }
            )
            "drugs" -> DrugScreen(onBack = { screen = "home" })
            "terms" -> TermScreen(onBack = { screen = "home" })
            "nursing" -> InfoScreen("أساسيات التمريض", listOf(
                "غسل اليدين ومكافحة العدوى",
                "قياس العلامات الحيوية",
                "تقييم المريض وتوثيق الملاحظات",
                "السلامة عند إعطاء الأدوية",
                "العناية بالقسطرة والضمادات"
            ), { screen = "home" })
            "procedures" -> InfoScreen("الإجراءات التمريضية", listOf(
                "تركيب ومتابعة المحاليل الوريدية",
                "العناية بالجرح وتغيير الغيار",
                "قياس سكر الدم",
                "تجهيز المريض للإجراء",
                "مراقبة المريض بعد الإجراء"
            ), { screen = "home" })
            "emergency" -> InfoScreen("الطوارئ والإسعافات", listOf(
                "تقييم ABCDE",
                "الإنعاش القلبي الرئوي حسب البروتوكول",
                "التعامل الأولي مع نقص الأكسجين",
                "التعامل مع النزيف",
                "طلب المساعدة وتوثيق الحالة"
            ), { screen = "home" })
            "study" -> InfoScreen("المذاكرة والمراجعة", listOf(
                "العلامات الحيوية",
                "حسابات الجرعات",
                "مبادئ مكافحة العدوى",
                "مصطلحات التمريض",
                "مراجعة الأدوية الشائعة"
            ), { screen = "home" })
            "calculator" -> CalculatorScreen { screen = "home" }
        }
    }
}

@Composable
fun HomeScreen(search: String, onSearch: (String) -> Unit, onSection: (String) -> Unit) {
    val sections = listOf(
        "drugs" to "دليل الأدوية" to Icons.Default.MedicalServices,
        "calculator" to "الحاسبات الطبية" to Icons.Default.Calculate,
        "nursing" to "أساسيات التمريض" to Icons.Default.LocalHospital,
        "terms" to "المصطلحات الطبية" to Icons.Default.Translate,
        "procedures" to "الإجراءات التمريضية" to Icons.Default.Favorite,
        "emergency" to "الطوارئ والإسعافات" to Icons.Default.Emergency,
        "study" to "المذاكرة والمراجعة" to Icons.Default.School
    )
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(16.dp)) {
        Spacer(Modifier.height(20.dp))
        Text("Hakamo", color = MaterialTheme.colorScheme.primary, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
        Text("مساعدك في كل ما يخص التمريض", color = Color.White.copy(.85f), fontSize = 16.sp)
        Spacer(Modifier.height(18.dp))
        OutlinedTextField(
            value = search, onValueChange = onSearch, modifier = Modifier.fillMaxWidth(),
            singleLine = true, placeholder = { Text("ابحث داخل التطبيق...") },
            leadingIcon = { Icon(Icons.Default.Search, null) }, shape = RoundedCornerShape(18.dp)
        )
        Spacer(Modifier.height(18.dp))
        Text("الأقسام الرئيسية", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        val filtered = sections.filter { search.isBlank() || it.second.contains(search, true) }
        LazyVerticalGrid(columns = GridCells.Fixed(2), horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
            items(filtered) { item ->
                Card(Modifier.fillMaxWidth().height(145.dp).clickable { onSection(item.first) },
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.SpaceBetween) {
                        Icon(item.third, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(34.dp))
                        Text(item.second, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun TopBar(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(bottom = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "رجوع", tint = Color.White) }
        Text(title, color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun DrugScreen(onBack: () -> Unit) {
    var query by remember { mutableStateOf("") }
    val filtered = drugs.filter { it.name.contains(query, true) || it.generic.contains(query, true) }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(16.dp)) {
        TopBar("دليل الأدوية", onBack)
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("ابحث باسم الدواء...") })
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(filtered) { d ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(14.dp)) {
                        Text(d.name, color = MaterialTheme.colorScheme.primary, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        Text(d.generic, color = Color.White.copy(.7f))
                        Spacer(Modifier.height(6.dp))
                        Text("الاستخدام: ${d.use}", color = Color.White)
                        Text("تنبيه: ${d.warning}", color = Color.White.copy(.75f), fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun TermScreen(onBack: () -> Unit) {
    var query by remember { mutableStateOf("") }
    val filtered = terms.filter { it.ar.contains(query, true) || it.en.contains(query, true) }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(16.dp)) {
        TopBar("المصطلحات الطبية", onBack)
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("ابحث عربي أو English...") })
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(filtered) { t ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(14.dp)) {
                        Text(t.ar, color = MaterialTheme.colorScheme.primary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text(t.en, color = Color.White)
                        Text(t.desc, color = Color.White.copy(.75f))
                    }
                }
            }
        }
    }
}

@Composable
fun InfoScreen(title: String, points: List<String>, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(16.dp)) {
        TopBar(title, onBack)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(points) { point ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CheckCircle, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(10.dp))
                        Text(point, color = Color.White, fontSize = 16.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun CalculatorScreen(onBack: () -> Unit) {
    var volume by remember { mutableStateOf("") }
    var hours by remember { mutableStateOf("") }
    var minutes by remember { mutableStateOf("") }
    var drops by remember { mutableStateOf("20") }
    val v = volume.toDoubleOrNull()
    val h = hours.toDoubleOrNull() ?: 0.0
    val m = minutes.toDoubleOrNull() ?: 0.0
    val totalHours = h + m / 60.0
    val rate = if (v != null && totalHours > 0) v / totalHours else null
    val gtt = if (v != null && totalHours > 0) (v * (drops.toDoubleOrNull() ?: 20.0) / (totalHours * 60)).toInt() else null

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(16.dp)) {
        TopBar("حاسبة المحاليل", onBack)
        Text("احسب معدل المحلول بالـ mL/hour و gtt/min", color = Color.White.copy(.75f))
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(volume, { volume = it }, Modifier.fillMaxWidth(), label = { Text("الحجم mL") }, singleLine = true)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(hours, { hours = it }, Modifier.fillMaxWidth(), label = { Text("الساعات") }, singleLine = true)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(minutes, { minutes = it }, Modifier.fillMaxWidth(), label = { Text("الدقائق") }, singleLine = true)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(drops, { drops = it }, Modifier.fillMaxWidth(), label = { Text("عامل التنقيط gtt/mL") }, singleLine = true)
        Spacer(Modifier.height(18.dp))
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(16.dp)) {
                Text("النتيجة", color = MaterialTheme.colorScheme.primary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("معدل المحلول: ${rate?.let { "%.1f".format(it) } ?: "—"} mL/hour", color = Color.White)
                Text("معدل التنقيط: ${gtt ?: "—"} gtt/min", color = Color.White)
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("تنبيه: الحاسبة للمساعدة التعليمية فقط. راجع الوصفة، نوع المحلول، مجموعة التنقيط وبروتوكول المنشأة قبل التطبيق.", color = Color(0xFFFFCC80), fontSize = 13.sp)
    }
}
